#!/usr/bin/env python3
"""
Temenos RAG AI Client
Core functionality for interacting with Temenos RAG API and generating RFP responses.
"""

import requests
import json
import re
import os
import glob
from datetime import datetime
from typing import Dict, List, Optional, Any
from shared_config import API_CONFIG, CATEGORY_TO_MODEL

class TemenosRAGClient:
    """Main client for Temenos RAG AI operations"""
    
    def __init__(self, jwt_token: str = None):
        self.jwt_token = jwt_token or API_CONFIG['jwt_token']
        self.base_url = API_CONFIG['base_url']
        self.timeout = API_CONFIG['timeout']
        
        # Technology pillars configuration for RFP responses
        self.technology_pillars = {
            "Architecture": {
                "description": "Overall system architecture, deployment options, cloud capabilities, and infrastructure design",
                "context": "focus on architectural overview, deployment options, cloud capabilities, and infrastructure design",
                "questions": [
                    "What is the overall architectural approach and design philosophy of {product}?",
                    "What are the main architectural components and how do they interact with each other?",
                    "What deployment options are available (cloud, on-premises, hybrid) and their characteristics?",
                    "How does {product} handle scalability and what are the scaling mechanisms?",
                    "What are the high availability and disaster recovery architectural features?",
                    "How is {product} designed for performance and what are the key performance characteristics?",
                    "What architectural patterns are used (microservices, layered, event-driven) and why?",
                    "How does the architecture support different deployment environments and configurations?"
                ]
            },
            "Extensibility": {
                "description": "Extensibility features, customization capabilities, configuration tools, and developer frameworks",
                "context": "focus on extensibility features, customization capabilities, configuration tools, and developer frameworks",
                "questions": [
                    "What extensibility and customization capabilities are available for tailoring {product}?",
                    "What development tools, frameworks, and APIs are provided for customization?",
                    "How can {product} be configured and customized without modifying core code?",
                    "What plugin and extension mechanisms are available for adding new functionality?",
                    "How does {product} support third-party integrations and custom adapters?",
                    "What low-code or no-code development capabilities are available?",
                    "How does {product} handle configuration management and environment-specific settings?",
                    "What testing and validation tools are available for custom extensions?"
                ]
            },
            "DevOps": {
                "description": "Deployment automation, CI/CD capabilities, testing frameworks, and operational tools",
                "context": "focus on deployment automation, CI/CD capabilities, testing frameworks, and operational tools",
                "questions": [
                    "What DevOps and deployment automation capabilities are available in {product}?",
                    "What CI/CD pipeline features and automation tools are provided?",
                    "How does {product} support automated testing and quality assurance?",
                    "What deployment strategies and rollback mechanisms are available?",
                    "How does {product} handle infrastructure management and provisioning?",
                    "What monitoring and alerting capabilities are available for operations?",
                    "How does {product} support continuous integration and continuous deployment?",
                    "What operational tools and dashboards are available for system management?"
                ]
            },
            "Security": {
                "description": "Security features, compliance standards, authentication, authorization, and data protection",
                "context": "focus on security features, compliance standards, authentication, authorization, and data protection",
                "questions": [
                    "What security features and capabilities are built into {product}?",
                    "How does {product} handle authentication and user identity management?",
                    "What authorization and access control mechanisms are available?",
                    "What encryption and data protection features are provided?",
                    "What compliance standards and regulatory requirements are supported?",
                    "How does {product} handle security monitoring and threat detection?",
                    "What audit and logging capabilities are available for security events?",
                    "How does {product} support security policies and governance?"
                ]
            },
            "Observability": {
                "description": "Monitoring capabilities, logging, metrics, dashboards, and operational visibility",
                "context": "focus on monitoring capabilities, logging, metrics, dashboards, and operational visibility",
                "questions": [
                    "What observability and monitoring capabilities are available in {product}?",
                    "What logging and audit trail features are provided?",
                    "What metrics collection and performance monitoring tools are available?",
                    "What dashboards and reporting capabilities are provided for operations?",
                    "How does {product} handle alerting and notification management?",
                    "What tracing and debugging capabilities are available for troubleshooting?",
                    "How does {product} support operational analytics and insights?",
                    "What health monitoring and status reporting features are available?"
                ]
            },
            "Integration": {
                "description": "API capabilities, integration patterns, data streaming, and connectivity options",
                "context": "focus on API capabilities, integration patterns, data streaming, and connectivity options",
                "questions": [
                    "What integration capabilities and connectivity options are available in {product}?",
                    "What APIs and web services are provided for system integration?",
                    "How does {product} support real-time data streaming and event processing?",
                    "What messaging and queuing capabilities are available for integration?",
                    "How does {product} handle data synchronization and consistency?",
                    "What protocol support and communication standards are available?",
                    "How does {product} support batch processing and file-based integration?",
                    "What integration monitoring and error handling capabilities are provided?"
                ]
            }
        }
    
    def test_connection(self) -> bool:
        """Test connection to Temenos RAG API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.jwt_token}",
                "Content-Type": "application/json"
            }
            response = requests.get(f"{self.base_url}/models", headers=headers, timeout=self.timeout)
            return response.status_code == 200
        except Exception:
            return False
    
    def query_rag(self, question: str, region: str, model_id: str, context: str = "") -> Optional[Dict]:
        """Query the RAG API with a question"""
        try:
            headers = {
                "Authorization": f"Bearer {self.jwt_token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "question": question,
                "region": region,
                "model_id": model_id,
                "context": context
            }
            
            response = requests.post(
                f"{self.base_url}/query",
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
                
        except Exception:
            return None
    
    def analyze_pillar(self, region: str, model_id: str, product_name: str, pillar: str) -> Dict:
        """Analyze a specific technology pillar"""
        pillar_config = self.technology_pillars[pillar]
        context = pillar_config["context"]
        
        # Prepare analysis data
        pillar_data = {
            "pillar": pillar,
            "product": product_name,
            "region": region,
            "model_id": model_id,
            "questions_asked": [],
            "answers": [],
            "conversation_flow": [],
            "key_points": [],
            "timestamp": datetime.now().isoformat()
        }
        
        # Ask base questions
        base_questions = pillar_config["questions"]
        for i, question_template in enumerate(base_questions, 1):
            question = question_template.format(product=product_name)
            
            response = self.query_rag(question, region, model_id, context)
            
            if response:
                data = response.get('data', {})
                answer = data.get('answer', 'No answer received') if data else 'No answer received'
                
                if answer and answer.lower() not in ['no answer received', 'no answer', '']:
                    pillar_data["questions_asked"].append(question)
                    pillar_data["answers"].append(answer)
                    pillar_data["conversation_flow"].append({
                        "phase": "base",
                        "question": question,
                        "answer": answer,
                        "timestamp": datetime.now().isoformat()
                    })
                    
                    key_points = self._extract_key_points_from_answer(answer)
                    pillar_data["key_points"].extend(key_points)
        
        # Generate summary
        pillar_data["summary"] = self._generate_pillar_summary(pillar_data)
        
        return pillar_data
    
    def _extract_key_points_from_answer(self, answer: str) -> List[str]:
        """Extract key points from an answer"""
        # Simple key point extraction - split by sentences and filter
        sentences = re.split(r'[.!?]+', answer)
        key_points = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20 and not sentence.startswith(('I cannot', 'I don\'t', 'I\'m not')):
                key_points.append(sentence)
        
        return key_points[:3]  # Limit to 3 key points per answer
    
    def _generate_pillar_summary(self, pillar_data: Dict) -> str:
        """Generate a summary for the pillar analysis"""
        pillar = pillar_data['pillar']
        product = pillar_data['product']
        key_points_count = len(pillar_data['key_points'])
        
        return f"Comprehensive {pillar} analysis for {product} completed. Identified {key_points_count} key technical capabilities and business value propositions suitable for RFP response preparation."
    
    def save_analysis(self, pillar_data: Dict) -> str:
        """Save pillar analysis to JSON file"""
        reports_dir = "reports"
        if not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        pillar = pillar_data['pillar'].lower().replace(" ", "_")
        product = pillar_data['product'].lower().replace(" ", "_").replace("temenos_", "")
        
        filename = f"pillar_analysis_{product}_{pillar}_{timestamp}.json"
        filepath = os.path.join(reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(pillar_data, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def get_available_models(self) -> List[str]:
        """Get list of available models"""
        return list(CATEGORY_TO_MODEL.values())
    
    def get_technology_pillars(self) -> List[str]:
        """Get list of available technology pillars"""
        return list(self.technology_pillars.keys())
